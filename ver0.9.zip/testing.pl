#!/usr/bin/perl -w
use List::Util qw(first max maxstr min minstr reduce shuffle sum);

die "Incorrect number of arguments supported\n" if $#ARGV != 1;

my $input = $ARGV[0] or die "Cooresponding input file not supported\n";
my $output = $ARGV[1] or die "Output file not supported\n";

open(Finput,"<$input") or die "Input file doesn't exist";
open(Foutput,"<$output") or die "Output file doesn't exist";

open(Fanalysis, ">", "./analysis.log") or die "Can not create the file analysis.log";

print Fanalysis "Analysis on the output file $output.\nBase on the input file $input.\n";

# global varialbes
$output_buyTotal = 0;
$output_sellTotal = 0;
$input_buyTotal = 0;
$input_sellTotal = 0;
my @sellPair;
my @buyPair;
# reading output
@outputLines = <Foutput>;
shift @outputLines;
foreach my $line (@outputLines) {
    chomp $line;
    my @fields = split "," , $line;
    $fields[2] =~ s/\.\d\d\d//;
    $fields[2] =~ s/\://g;
    if ($fields[12] eq 'A') {
        push @sellPair, $fields[7];
        $output_sellTotal += $fields[7];

    } elsif ($fields[12] eq 'B') {
        push @buyPair, $fields[7];
        $output_buyTotal += $fields[7];

    } else {
        die "The output does not follow the sirca format";
    }
}
close (Foutput);

# reading input
@inputLines = <Finput>;

foreach my $line (@inputLines) {
    chomp $line;
    my @fields = split "," , $line;
    # $fields[2] =~ s/\.\d\d\d//;
    # $fields[2] =~ s/\://g;

    if ($fields[3] =~ "ENTER") {
        # print "$fields[7]\n";
        if ($fields[12] eq 'A') {
            $input_sellTotal += $fields[7];

        } elsif ($fields[12] eq 'B') {
            $input_buyTotal += $fields[7];

        } else {
            die "The input does not follow the sirca format";
        }
    }
}
close (Finput);

# orderbook merge



print Fanalysis "First Testing Methond: Immediate Execution\n";
$netincome = $output_sellTotal - $output_buyTotal;
print Fanalysis "
Total money spent purchasing stock $output_buyTotal.
Total money gained selling stock $output_sellTotal.
Total net income/loss = $netincome.
";

$netincome = $input_sellTotal - $input_buyTotal;
print Fanalysis "
Total money spent purchasing stock $input_buyTotal from input file.
Total money gained selling stock $input_sellTotal from input file.
Total net income/loss = $netincome.
";



print Fanalysis "Second Testing Method: Trading Pair\n";
print Fanalysis "Buy/Sell Pair | Return Calculation | Return Value\n";
my $total_return_per=0;
foreach my $buy (@buyPair) {
    $sell = shift @sellPair;
    last if (!defined $sell);
    my $dif = $buy-$sell;
    my $retval = $dif/$buy;
    my $percent = $retval * 100;
    print Fanalysis 'Buy@',$buy,', Sell@',$sell,"|($sell-$buy)/$buy|";
    printf Fanalysis "%.4f", $percent;
    print Fanalysis "\%\n";
    $total_return_per += $percent;
}
print Fanalysis "Total Gain/Loss | | ";
printf Fanalysis "%.4f", $total_return_per;
print Fanalysis "\%\n\n\n";

print Fanalysis "Third Testing Method: Executation with no Impact Analysis\n";

# generate the order book

my @merged;
my $inputLine = shift @inputLines;
$inputLine = shift @inputLines;
foreach my $outputLine (@outputLines) {
    chomp $outputLine;
    my @fields = split "," , $outputLine;
    $fields[2] =~ s/\.\d\d\d//;
    $fields[2] =~ s/\://g;

    if (defined $inputLine) {
        chomp $inputLine;
        my @fieldsI = split "," , $inputLine;
        $fieldsI[2] =~ s/\.\d\d\d//;
        $fieldsI[2] =~ s/\://g;
        while (defined $inputLine
            and $fieldsI[2] lt $fields[2]) {
            push @merged, $inputLine;
            $inputLine = shift @inputLines;
            if (defined $inputLine) {
                chomp $inputLine;
                @fieldsI = split "," , $inputLine;
                $fieldsI[2] =~ s/\.\d\d\d//;
                $fieldsI[2] =~ s/\://g;

            }
        }
    }
    push @merged, $outputLine;

}

while (defined $inputLines) {
    push @merged, $inputLines;
    $inputLine = shift @inputLines;
    chomp $inputLine;
    my @fieldsI = split "," , $inputLine;
    $fieldsI[2] =~ s/\.\d\d\d//;
    $fieldsI[2] =~ s/\://g;
}

my @mergedEnter;
foreach my $x (@merged) {
    if ($x =~ "ENTER") {
        push @mergedEnter, $x;
    }
}

my %pricehash;
my $output_sellTotal_success;
my $output_buyTotal_success;

foreach my $x (@mergedEnter) {
    @fields = split "," , $x;

    if ($fields[10] =~ /[0]{19}/
        or $fields[11] =~ /[0]{19}/) {

        if ($fields[12] eq 'A') {
            if ($pricehash{$fields[4]} + $fields[5] <= 0) {
                $pricehash{$fields[4]} += $fields[5];
                $output_sellTotal_success += $fields[7]
            }

        } elsif ($fields[12] eq 'B') {
            if ($pricehash{$fields[4]} - $fields[5] <= 0) {
                $pricehash{$fields[4]} -= $fields[5];
                $output_buyTotal_success += $fields[7]
            }

        } else {
            die "The input does not follow the sirca format";
        }

    } elsif ($fields[10] eq ''
        and $fields[11] eq ''){
        # do nothing
    } else {
        if ($fields[12] eq 'A') {
            $pricehash{$fields[4]} += $fields[5];
        } elsif ($fields[12] eq 'B') {
            $pricehash{$fields[4]} -= $fields[5];
        } else {
            die "The input does not follow the sirca format";
        }
    }

}

$netincome = $output_sellTotal_success - $output_buyTotal_success;
print Fanalysis "
Total money successfully spent purchasing stock $output_buyTotal_success.
Total money successfully gained selling stock $output_sellTotal_success.
Total successful net income/loss = $netincome.
";

print "done\n";
