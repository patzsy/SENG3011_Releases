drop table if exists OrderRecord;
create table OrderRecord (
    Instrument              varchar(3),
    Date                    text,
    Time                    text,
    Record_Type             varchar(6)
                 CHECK (Record_Type IN ("ENTER", 
                                        "AMEND", 
                                        "DELETE", 
                                        "OFFTR", 
                                        "TRADE", 
                                        "CANCEL_TRADE")),
    Price                   double,
    Volume                  integer,
    Undisclosed_Volume      integer,
    value                   double,
    Qualifiers              varchar(10),
    Trans_ID                integer,
    Bid_ID                  varchar(30),
    Ask_ID                  varchar(30),
    Bid_Ask                 varchar(1),
    Entry_Time              text,
    Old_Price               double,
    Old_Volume              integer,
    Buyer_Broker_ID         integer,
    Seller_Broker_ID        integer
);