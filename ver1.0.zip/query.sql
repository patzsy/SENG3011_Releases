-- .separator ","
-- .import nameofthefile.csv OrderRecord
-- Query For Bid ENTER
drop table if exists BID_ENTER;
drop table if exists BID_AMEND;
drop table if exists BID_DELETE;
drop table if exists ASK_ENTER;
drop table if exists ASK_AMEND;
drop table if exists ASK_DELETE;
drop table if exists TRADE;
drop table if exists OFFTR;
drop table if exists CANCLE_TRADE;

Create table BID_ENTER as
SELECT Instrument,
        (Date || 'T' ||Time) as Datetimevalue,
        Record_Type,
        Price,
        Volume,
        Undisclosed_Volume,
        Value,
        Qualifiers,
        Trans_ID,
        Bid_ID,
        Buyer_Broker_ID
                From OrderRecord
                Where Record_Type == 'ENTER' and Bid_Ask == 'B'
;
-- Query for bid AMEND

Create table BID_AMEND as
SELECT Instrument,
        (Date || 'T' ||Time) as Datetimevalue,
        Record_Type,
        Price,
        Volume,
        Undisclosed_Volume,
        Value,
        Qualifiers,
        Trans_ID,
        Bid_ID,
        Entry_Time,
        Old_Volume,
        Old_Price,
        Buyer_Broker_ID
                From OrderRecord
                Where Record_Type == 'AMEND' and Bid_Ask == 'B'
;

-- Query for bid DELETE
Create table BID_DELETE as 
SELECT Instrument,
        (Date || 'T' ||Time) as Datetimevalue,
        Record_Type,
        Qualifiers,
        Trans_ID,
        Bid_ID,
        Buyer_Broker_ID
                From OrderRecord
                Where Record_Type == 'DELETE' and Bid_Ask == 'B'
;

-- Query For ASK ENTER
Create table ASK_ENTER as 
SELECT Instrument,
        (Date || 'T' ||Time) as Datetimevalue,
        Record_Type,
        Price,
        Volume,
        Undisclosed_Volume,
        Value,
        Qualifiers,
        Trans_ID,
        Ask_ID,
        Seller_Broker_ID
                From OrderRecord
                Where Record_Type == 'ENTER' and Bid_Ask == 'A'
;

-- Query for ASK AMEND
Create table ASK_AMEND as 
SELECT Instrument,
        (Date || 'T' ||Time) as Datetimevalue,
        Record_Type,
        Price,
        Volume,
        Undisclosed_Volume,
        Value,
        Qualifiers,
        Trans_ID,
        Ask_ID,
        Entry_Time,
        Old_Volume,
        Old_Price,
        Seller_Broker_ID
                From OrderRecord
                Where Record_Type == 'AMEND' and Bid_Ask == 'A'
;

-- Query for ASK DELETE
Create table ASK_DELETE as 
SELECT Instrument,
        (Date || 'T' ||Time) as Datetimevalue,
        Record_Type,
        Qualifiers,
        Trans_ID,
        Ask_ID,
        Seller_Broker_ID
                From OrderRecord
                Where Record_Type == 'DELETE' and Bid_Ask == 'A'
;


-- Query for TRADE
Create table TRADE as 
SELECT Instrument,
        (Date || 'T' ||Time) as Datetimevalue,
        Record_Type,
        Price,
        Volume,
        Undisclosed_Volume,
        Value,
        Qualifiers,
        Trans_ID,
        Buyer_Broker_ID,
        Seller_Broker_ID
                From OrderRecord
                Where Record_Type == 'TRADE'
;

-- Query for OFFTR
Create table OFFTR as 
SELECT Instrument,
        (Date || 'T' ||Time) as Datetimevalue,
        Record_Type,
        Price,
        Volume,
        Value,
        Qualifiers,
        Trans_ID,
        Bid_ID,
        Ask_ID,
        Bid_Ask,
        Buyer_Broker_ID,
        Seller_Broker_ID
                From OrderRecord
                Where Record_Type == 'OFFTR'
;

-- Query for CANCLE_TRADE
Create table CANCLE_TRADE as 
SELECT Instrument,
        (Date || 'T' ||Time) as Datetimevalue,
        Record_Type,
        Price,
        Volume,
        Undisclosed_Volume,
        Value,
        Trans_ID
                From OrderRecord
                Where Record_Type == 'CANCLE_TRADE'
;